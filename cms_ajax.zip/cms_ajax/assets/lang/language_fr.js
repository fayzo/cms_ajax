var fr ={
        "welcome": "Bienvenu",
        "afternoon": "Good afternoom",
        "pets": [{
                "animal": "dog",
                "name": "Fido"
            },
            {
                "animal": "cat",
                "name": "Felix"
            },
            {
                "animal": "hamster",
                "name": "Lightning"
            }
        ]
};